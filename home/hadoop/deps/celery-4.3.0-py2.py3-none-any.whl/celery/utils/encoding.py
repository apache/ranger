# -*- coding: utf-8 -*-
"""**DEPRECATED**: This module has moved to :mod:`kombu.utils.encoding`."""
from __future__ import absolute_import, unicode_literals

from kombu.utils.encoding import (bytes_t, bytes_to_str,  # noqa
                                  default_encode, default_encoding,
                                  ensure_bytes, from_utf8, safe_repr,
                                  safe_str, str_t, str_to_bytes)
